-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 18, 2018 at 01:10 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sasurie_engg`
--

-- --------------------------------------------------------

--
-- Table structure for table `sce_achievement`
--

CREATE TABLE IF NOT EXISTS `sce_achievement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `achieversname` varchar(60) NOT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  PRIMARY KEY (`id`),
  KEY `k_sce_achievement` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sce_achievement`
--

INSERT INTO `sce_achievement` (`id`, `dept_id`, `achieversname`, `title`, `message`, `date`, `image1`) VALUES
(2, 106, 'aacse', 'cricket', 'aa  won medal', '2018-01-20', ''),
(3, 106, 'bbcse', 'basketball', 'bb won medal', '2018-05-09', ''),
(4, 106, 'aaece', 'football', 'aa  won medal', '2018-06-14', ''),
(5, 102, 'bbece', 'singing', 'bb got prize', '2018-08-08', ''),
(6, 103, 'aaeee', 'dancing', 'aa got prize', '2018-03-09', ''),
(7, 103, 'bbeee', 'drawing', 'bb got prize', '2018-04-10', ''),
(8, 104, 'aamech', 'singing', 'aa got prize', '2018-04-10', ''),
(9, 106, 'bbmech', 'throw ball', 'bb got medal', '2018-02-10', ''),
(10, 106, 'aacivil', 'football', 'aa got medal', '2018-09-09', ''),
(11, 105, 'bbcivil', 'singing', 'bb got prize', '2018-10-10', ''),
(12, 108, 'aaplace', 'drive', 'aa place in tcs', '2018-10-27', ''),
(13, 108, 'bbplace', 'drive', 'bb place in infosis', '2018-05-09', ''),
(14, 108, 'ccplace', 'drive', 'cc place In wipro', '2018-07-24', ''),
(15, 111, 'aame', 'carving', 'aa got prize', '2018-06-09', ''),
(16, 112, 'aamba', 'singing', 'aa got medal', '2018-04-10', '');

-- --------------------------------------------------------

--
-- Table structure for table `sce_admin`
--

CREATE TABLE IF NOT EXISTS `sce_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_deptid` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `sce_admin`
--

INSERT INTO `sce_admin` (`id`, `dept_id`, `username`, `password`) VALUES
(1, 101, 'aaa101@gmail.com', 'aaa101'),
(2, 101, 'bbb101@gmail.com', 'bbb101'),
(3, 102, 'arun102@gmail.com', 'arun102'),
(4, 102, 'kani102@gmail.com', 'kani102'),
(5, 103, 'rajesh103@gmail.com', 'rajesh103'),
(6, 103, 'priya103@gmail.com', 'priya103'),
(7, 104, 'gayu103@gmail.com', 'gayu104'),
(8, 104, 'dinesh104@gmail.com', 'dinesh104'),
(9, 105, 'ranju105@gmail.com', 'ranju105'),
(10, 105, 'pavi105@gmail.com', 'pavi105'),
(11, 106, 'mythili106@gmail.com', 'mythili106'),
(12, 107, 'sowrabi105@gmail.com', 'sowrabi105'),
(13, 108, 'aaa108@gmail.com', 'aaa108'),
(14, 109, 'ttt109@gmail.com', 'ttt109'),
(15, 110, 'kani110@gmail.com', 'kani110'),
(16, 111, 'ranju111@gmail.com', 'ranju111'),
(19, 111, 'pavi111@gmail.com', 'pavi111'),
(20, 112, 'arun112@gmail.com', 'arun112'),
(21, 113, 'rajesh113@gmail.com', 'rajesh113'),
(22, 114, 'niki114@gmail.com', 'niki114');

-- --------------------------------------------------------

--
-- Table structure for table `sce_advertisement`
--

CREATE TABLE IF NOT EXISTS `sce_advertisement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `reglink` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_sce_advertisement` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `sce_advertisement`
--

INSERT INTO `sce_advertisement` (`id`, `dept_id`, `title`, `message`, `date`, `image1`, `image2`, `image3`, `reglink`) VALUES
(2, 101, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'Https://srishta.com'),
(3, 101, 'quiz', 'this is quiz', '2018-05-14', '', '', '', 'https://quiz.com'),
(4, 102, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(5, 102, 'ppt', 'this is ppt', '2018-06-20', '', '', '', 'https://ppt.com'),
(6, 103, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(7, 103, 'multimedia', 'this is multimedia', '2018-09-10', '', '', '', 'https://multimedia.com'),
(8, 104, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(9, 104, 'photoshop', 'this is photoshop', '2018-05-09', '', '', '', 'https://photoshop.com'),
(10, 105, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(11, 105, 'proexpo', 'this is proexpo', '2018-04-10', '', '', '', 'https://proexpo.com'),
(12, 106, 'scricket', 'this is state level cricket', '2018-07-26', '', '', '', 'https://scricket.com'),
(13, 106, 'dcricket', 'this is district level', '2018-06-27', '', '', '', 'https://dcricket.com'),
(14, 111, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(15, 111, 'presentation', 'this is presentation', '2018-09-03', '', '', '', 'https://presentation.com'),
(16, 112, 'srishta', 'this is srishta', '2017-03-15', '', '', '', 'https://srishta.com'),
(17, 112, 'learnathon', 'this is learnathon', '2018-07-12', '', '', '', 'https://learn.com');

-- --------------------------------------------------------

--
-- Table structure for table `sce_alumni_form`
--

CREATE TABLE IF NOT EXISTS `sce_alumni_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_alumni_key_dept` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `sce_alumni_form`
--

INSERT INTO `sce_alumni_form` (`id`, `dept_id`, `name`, `email`, `contact`, `message`, `date`) VALUES
(1, 101, 'AAAA', 'aaaa@gmail.com', '9876543210', 'cfhkjugjklhlknmn', '2018-05-10'),
(2, 101, 'BBBB', 'bbbb@gmail.com', '9876543211', 'b vgvjkmbgcfvhkjjnhgv', '2018-06-01'),
(3, 101, 'CCCCC', 'cccc@gmail.com', '987654322', 'vhghjnngfdgvhkuyyjnk', '2018-05-10'),
(4, 102, 'AAAA', 'aaaaa@gmail.com', '9876543212', 'cbcjjcngyhbjutthlkkiu', '2018-05-15'),
(5, 102, 'CCCCC', 'ccccc@gmail.com', '9876543213', 'vhtfgvkkjiytdhkji', '2018-07-05'),
(6, 103, 'ARUN', 'arun@gmail.com', '9876543123', 'nnhuygftfdsrijoojnn', '2018-07-09'),
(7, 104, 'RAJESH', 'rajesh@gmail.com', '9876556789', 'bvvbjnkhffhk', '2018-06-06'),
(8, 104, 'ARUN', 'arunn@gmail.com', '9876543456', 'xvvhbzxcvvbbnmmkjhgfd', '2018-07-04'),
(9, 105, 'CCCCC', 'cccc105@gmail.com', '9876543098', 'ertyuioplkjhgfddssa', '2018-09-01'),
(10, 101, 'NIKITHA', 'nikitha@gmail.com', '9123456789', 'qwertyuiplkkjhgfddsazxcvb', '2017-09-09'),
(11, 101, 'PRIYA', 'priya@gmail.com', '9123456788', 'qsazxcvvbnmkloiujhgfd', '2017-12-12'),
(12, 111, 'PAVITHRA', 'pavithra@gmail.com', '9212345679', 'wertgfdsazxcvbnmkjjhyuii', '2017-11-09'),
(13, 112, 'KANI', 'kani@gmail.com', '9012345678', 'qwedsazxcfrvgtbhy', '2018-01-05'),
(14, 114, 'RANJANI', 'ranjani@gmail.com', '9012234567', 'erdfhyujiknbgfvcdolkm', '2017-07-05'),
(15, 115, 'NIKITHA', 'nikitha123@gmail.com', '9876543092', 'ujhytgnbvfdcesx', '2018-04-07'),
(16, 115, 'ARUN', 'arunak@gmail.com', '9123408712', 'frtgv cvnnljughjkmkikjmjbgfdfhk', '2018-04-10'),
(17, 116, 'PRIYA', 'priya123@gmail.com', '9876540981', 'qwsazxdecfrvbgnthyjmkilop', '2017-03-08'),
(18, 116, 'RAJESH', 'rej2gmail.com', '9807654212', 'ertfdcvbghynujmkilopwsx', '2018-02-09'),
(19, 111, 'KANI', 'kanii@gmail.com', '8765432190', 'qwsaxczdexrfvbgtyhnuimlo', '2018-05-10'),
(20, 112, 'RANJANI', 'ranju@gmail.com', '8765903211', 'wsqoplikjumnbhytgbvfr', '2018-01-17');

-- --------------------------------------------------------

--
-- Table structure for table `sce_department`
--

CREATE TABLE IF NOT EXISTS `sce_department` (
  `dept_id` int(11) NOT NULL DEFAULT '0',
  `dept_name` varchar(40) NOT NULL,
  `dept_type` varchar(3) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sce_department`
--

INSERT INTO `sce_department` (`dept_id`, `dept_name`, `dept_type`) VALUES
(101, 'CSE', 'UG'),
(102, 'ECE', 'UG'),
(103, 'EEE', 'UG'),
(104, 'MECH', 'UG'),
(105, 'CIVIL', 'UG'),
(106, 'Sports Department', 'SD'),
(107, 'Transport Department', 'TD'),
(108, 'Placement Department', 'PD'),
(109, 'Administration Department', 'AD'),
(110, 'Library Department', 'LD'),
(111, 'ME(CSE)', 'PG'),
(112, 'MBA', 'PG'),
(113, 'VLSI', 'PG'),
(114, 'PED', 'PG'),
(115, 'Applied Electronics', 'PG'),
(116, 'M.Tech(IT)', 'PG');

-- --------------------------------------------------------

--
-- Table structure for table `sce_department_details`
--

CREATE TABLE IF NOT EXISTS `sce_department_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `dept_message` longtext,
  `dept_sub_message1` longtext,
  `dept_sub_message2` longtext,
  `dept_sub_message3` longtext,
  `dept_sub_message4` longtext,
  `dept_sub_message5` longtext,
  `dept_hod_name` varchar(60) NOT NULL,
  `dept_hod_address` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_deptid` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `sce_department_details`
--

INSERT INTO `sce_department_details` (`id`, `dept_id`, `dept_message`, `dept_sub_message1`, `dept_sub_message2`, `dept_sub_message3`, `dept_sub_message4`, `dept_sub_message5`, `dept_hod_name`, `dept_hod_address`) VALUES
(2, 101, 'this is cse', 'aacse', 'bbcse', 'cccse', 'ddcse', 'eecse', 'hodcse', 'addcse'),
(3, 102, 'this is ece', 'aaece', 'bbece', 'ccece', 'ddece', 'eeece', 'hodece', 'addece'),
(4, 103, 'this is eee', 'aaeee', 'bbeee', 'cceee', 'ddeee', 'eeeee', 'hodeee', 'addeee'),
(5, 104, 'this is mech', 'aamech', 'bbmech', 'ccmech', 'ddmech', 'eemech', 'hodmech', 'addmech'),
(6, 105, 'this is civil', 'aacivil', 'bbcivil', 'cccivil', 'ddcivil', 'eecivil', 'hodcivil', 'addcivil'),
(7, 106, 'this is sports', 'aasports', 'bbsports', 'ccsports', 'ddsports', 'eesports', 'hodsports', 'addsports'),
(8, 107, 'this is transport', 'aatrans', 'bbsports', 'ccsports', 'ddsports', 'eesports', 'hodsports', 'addsports'),
(9, 108, 'this is placement', 'aaplace', 'bbplace', 'ccplace', 'ddplace', 'eeplace', 'hodplace', 'addplace'),
(10, 109, 'this is administration', 'aaadmin', 'bbadmin', 'ccadmin', 'ddadmin', 'eeadmin', 'hodadmin', 'addadmin'),
(11, 110, 'this is library', 'aalib', 'bblib', 'cclib', 'ddlib', 'eelib', 'hodlib', 'addlib'),
(12, 111, 'this is me', 'aame', 'bbme', 'ccme', 'ddme', 'eeme', 'hodme', 'addme'),
(13, 112, 'this is mba', 'aamba', 'bbmba', 'ccmba', 'ddmba', 'eemba', 'hodmba', 'addmba'),
(14, 113, 'this is vlsi', 'aavlsi', 'bbvlsi', 'ccvlsi', 'ddvlsi', 'eevlsi', 'hodvlsi', 'addvlsi'),
(15, 114, 'this is ped', 'aaped', 'bbped', 'ccped', 'ddped', 'eeped', 'hodped', 'addped'),
(16, 115, 'this is applied electronics', 'aaae', 'bbae', 'ccae', 'ddae', 'eeae', 'hodae', 'addae'),
(17, 116, 'this is m.tech', 'aamtech', 'bbmtech', 'ccmtech', 'ddmtech', 'eemtech', 'hodmtech', 'addmtech');

-- --------------------------------------------------------

--
-- Table structure for table `sce_facilities`
--

CREATE TABLE IF NOT EXISTS `sce_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `image1` blob,
  `image2` blob,
  `image4` blob,
  `image5` blob,
  `image6` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_facilities` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `sce_facilities`
--

INSERT INTO `sce_facilities` (`id`, `dept_id`, `title`, `image1`, `image2`, `image4`, `image5`, `image6`, `message`) VALUES
(2, 101, 'lab', '', '', '', '', '', 'cse have lab'),
(3, 101, 'classroom', '', '', '', '', '', 'cse have  classroom'),
(4, 102, 'lab', '', '', '', '', '', 'ece have lab'),
(5, 102, 'classroom', '', '', '', '', '', 'ece have classroom'),
(6, 103, 'lab', '', '', '', '', '', 'eee have lab'),
(7, 103, 'classroom', '', '', '', '', '', 'eee have classroom'),
(8, 104, 'lab', '', '', '', '', '', 'mech have lab'),
(9, 104, 'classroom', '', '', '', '', '', 'mech have classroom'),
(10, 105, 'lab', '', '', '', '', '', 'civil have lab'),
(11, 105, 'classroom', '', '', '', '', '', 'civil have classroom'),
(12, 106, 'play ground', '', '', '', '', '', 'sd have playground'),
(13, 107, 'buses', '', '', '', '', '', 'we have buses'),
(14, 108, 'placementcell', '', '', '', '', '', 'we have placement  cell'),
(15, 109, 'administration', '', '', '', '', '', 'we have administration office'),
(16, 110, 'library', '', '', '', '', '', 'we have books'),
(17, 111, 'lab', '', '', '', '', '', 'me have lab and classes'),
(18, 112, 'mba', '', '', '', '', '', 'we have classrooms');

-- --------------------------------------------------------

--
-- Table structure for table `sce_faculty_details`
--

CREATE TABLE IF NOT EXISTS `sce_faculty_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_faculty_dept` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `sce_faculty_details`
--

INSERT INTO `sce_faculty_details` (`id`, `dept_id`, `name`, `degree`, `designation`) VALUES
(2, 101, 'aacse', 'phd', 'hod'),
(3, 101, 'bbcse', 'bsccs', 'ap'),
(4, 101, 'cccse', 'msccs', 'ap'),
(5, 102, 'aaece', 'phd', 'hod'),
(6, 102, 'bbece', 'bsce', 'ap'),
(7, 102, 'ccece', 'me', 'ap'),
(8, 103, 'aaeee', 'meeee', 'hod'),
(9, 103, 'bbeee', 'mphil', 'ap'),
(10, 103, 'cceee', 'msce', 'ap'),
(11, 104, 'aamech', 'me', 'hod'),
(12, 104, 'bbmech', 'msc', 'ap'),
(13, 104, 'ccmech', 'me', 'ap'),
(14, 105, 'aacivil', 'mecivil', 'hod'),
(15, 105, 'bbcivil', 'mphil', 'ap'),
(16, 105, 'cccivil', 'msc', 'ap'),
(17, 106, 'aapt', 'be', 'staff'),
(18, 106, 'bbpt', 'bsccs', 'staff'),
(19, 107, 'aatrans', 'bsccs', 'staff'),
(20, 107, 'bbtrans', 'msccs', 'staff'),
(21, 108, 'aaplace', 'mecse', 'trainer'),
(22, 108, 'bbplace', 'beece', 'staff'),
(23, 109, 'aaadmin', 'msc', 'staff'),
(24, 109, 'bbadmin', 'bsccs', 'staff'),
(25, 110, 'aalib', 'bsccs', 'librarian'),
(26, 110, 'bblib', 'msc', 'staff'),
(27, 111, 'aame', 'mphil', 'hod'),
(28, 111, 'bbme', 'phd', 'ap'),
(29, 112, 'aamba', 'phd', 'hod'),
(30, 112, 'bbmba', 'mphil', 'ap'),
(31, 113, 'aavlsi', 'msc', 'hod'),
(32, 113, 'bbvlsi', 'me', 'ap'),
(33, 114, 'aaped', 'med', 'hod'),
(34, 114, 'bbped', 'phd', 'ap'),
(35, 115, 'aaae', 'mscae', 'hod'),
(36, 115, 'bbae', 'mphil', 'ap'),
(37, 116, 'aamtech', 'phd', 'hod'),
(38, 116, 'bbmtech', 'mphil', 'ap');

-- --------------------------------------------------------

--
-- Table structure for table `sce_lab`
--

CREATE TABLE IF NOT EXISTS `sce_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `message` longtext NOT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `image4` blob,
  PRIMARY KEY (`id`),
  KEY `k_sce_lab` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sce_lab`
--

INSERT INTO `sce_lab` (`id`, `dept_id`, `message`, `image1`, `image2`, `image3`, `image4`) VALUES
(1, 101, 'rfhcvbnmlkopiuhtgfed', NULL, NULL, NULL, NULL),
(2, 101, 'qwertyyuiopplkjhgfdsccbn', NULL, NULL, NULL, NULL),
(3, 102, 'awsqzxccderffvbgtyhhbnnjuimml', NULL, NULL, NULL, NULL),
(4, 102, 'rtgfvvbbhhnyuikmbccxdeswsxhlloo', NULL, NULL, NULL, NULL),
(5, 103, 'edrftgyhujikolpmjnhbgvfcdxs', NULL, NULL, NULL, NULL),
(6, 103, 'wsqaedzxrfftvvuhuikmnolgfrvderdd', NULL, NULL, NULL, NULL),
(7, 104, 'wasqzxderfcvvgtyhbbnjuikmmhgfvrwwqazxsd', NULL, NULL, NULL, NULL),
(8, 105, 'polikjqazswxderfcvinnmkjyyhgrfvb', NULL, NULL, NULL, NULL),
(9, 108, 'erfdcvvthydtrdwccv vnbkmoktoiugstfcfsg', NULL, NULL, NULL, NULL),
(10, 110, 'ersscgvhbvjnbdbkjbdjbbdjkk', NULL, NULL, NULL, NULL),
(11, 110, 'erdwwscxvhcjhgvihjppokmfnndvvg', NULL, NULL, NULL, NULL),
(12, 111, 'rfdttegevccwwsaxvcnnnjhuuiiokpmlmbnbgdrefd', NULL, NULL, NULL, NULL),
(13, 101, 'aaaaaaaaaaaaaccccccccccccddddddddd', NULL, NULL, NULL, NULL),
(14, 116, 'iyyyyyyyyyyyyyyyyyyyyyyhhhhhhh', NULL, NULL, NULL, NULL),
(15, 105, 'ppppppppppppppppoooooooooooooooooooooo', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sce_newsandevents`
--

CREATE TABLE IF NOT EXISTS `sce_newsandevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `image4` blob,
  `image5` blob,
  `image6` blob,
  `image7` blob,
  `image8` blob,
  `image9` blob,
  `image0` blob,
  PRIMARY KEY (`id`),
  KEY `k_sce_newsandevents` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sce_newsandevents`
--

INSERT INTO `sce_newsandevents` (`id`, `dept_id`, `title`, `message`, `date`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`, `image7`, `image8`, `image9`, `image0`) VALUES
(1, 101, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 101, 'quiz', 'this is quiz\r\n', '2018-05-14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 102, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 102, 'ppt', 'this is ppt\r\n', '2018-06-20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 103, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 103, 'multimedia', 'this is multimedia\r\n', '2018-09-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 104, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 104, 'photoshop', 'this is photoshop\r\n', '2018-05-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 105, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 105, 'proexpo', 'this is proexpo\r\n', '2018-04-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 106, 'scricket', 'this is state level cricket\r\n', '2018-07-26', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 106, 'dcricket', 'this is district level\r\n', '2018-06-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 111, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 111, 'presentation', 'this is presentation\r\n', '2018-09-03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 112, 'srishta', 'this is srishta\r\n', '2017-03-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 112, 'learnathon', 'this is learnathon\r\n', '2018-07-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sce_rd`
--

CREATE TABLE IF NOT EXISTS `sce_rd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_rd` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sce_rd`
--

INSERT INTO `sce_rd` (`id`, `dept_id`, `title`, `image1`, `image2`, `message`) VALUES
(1, 101, 'ALAB', NULL, NULL, 'thisssss issss aaaaaa lllllaaabbb'),
(2, 102, 'BLAB', NULL, NULL, 'iiiiikkkkkkhjjjjjjjjjjjssssssssss'),
(3, 101, 'SIT', NULL, NULL, 'sit is the research center of cse'),
(4, 104, 'CLAB', NULL, NULL, 'this is clab'),
(5, 105, 'BLAB', NULL, NULL, 'this is clab'),
(6, 104, 'JLAB', NULL, NULL, 'this is jlab'),
(7, 103, 'LLAB', NULL, NULL, 'this is llab'),
(8, 111, 'OLAB', NULL, NULL, 'this is olab'),
(9, 112, 'FLAB', NULL, NULL, 'this is flab'),
(10, 113, 'GLAB', NULL, NULL, 'this is glab'),
(11, 113, 'MLAB', NULL, NULL, 'this is mlab\r\n'),
(12, 114, 'LLAB', NULL, NULL, 'this is llab'),
(13, 114, 'ILAB', NULL, NULL, 'this is ilab'),
(14, 115, 'VLAB', NULL, NULL, 'this is vlab'),
(15, 116, 'SLAB', NULL, NULL, 'this is slab');

-- --------------------------------------------------------

--
-- Table structure for table `sce_request_form`
--

CREATE TABLE IF NOT EXISTS `sce_request_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(40) NOT NULL,
  `message` longtext NOT NULL,
  `date_time` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_requeast_key_dept` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `sce_request_form`
--

INSERT INTO `sce_request_form` (`id`, `dept_id`, `name`, `email`, `message`, `date_time`) VALUES
(2, 101, 'aaacse', 'aaacse@gmail.com', 'this is aaacse101', '2017-03-15'),
(3, 101, 'bbbcse', 'bbbcse@gmai.com', 'this is bbbcse101', '2018-05-14'),
(4, 102, 'aaaece', 'aaaece@gmail.com', 'this is aaaece102', '2017-03-15'),
(5, 102, 'bbbece', 'bbbece@gmail.com', 'this is bbbcse102', '2018-06-20'),
(6, 103, 'aaaeee', 'aaaeee@gmail.com', 'this is aaaeee103', '2017-03-15'),
(7, 103, 'bbbeee', 'bbbeee@gmail.com', 'this is bbbeee103', '2018-09-10'),
(8, 104, 'aaamech', 'aaamech@gmial.com', 'this is aaamech104', '2017-03-15'),
(9, 104, 'bbbmech', 'bbbmech@gmail.com', 'this is bbbmech104', '2018-05-09'),
(10, 105, 'aaacivil', 'aaacivil@mail.com', 'ths is aaacivil105', '2017-03-15'),
(11, 105, 'bbbcivil', 'bbbcivl@gmail.com', 'this is bbbcivil105', '2018-04-10'),
(12, 111, 'aaame', 'aaame@gmial.com', 'this is aaame111', '2018-07-26'),
(13, 111, 'bbbme', 'bbbme@gmail.com', 'this is bbbme111', '2018-06-27'),
(14, 111, 'cccme', 'cccme@gmail.com', 'this is cccme111', '2017-03-15'),
(15, 112, 'aaamba', 'aaamba@gmail.com', 'this ia aaamba112', '2018-09-03'),
(16, 112, 'bbbmba', 'bbbmba@gmail.com', 'this ia bbbmba112', '2017-03-15'),
(17, 112, 'cccmba', 'cccmba@gmail.com', 'this is cccmba112', '2018-07-12');

-- --------------------------------------------------------

--
-- Table structure for table `sce_tieups`
--

CREATE TABLE IF NOT EXISTS `sce_tieups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_tieups` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `sce_tieups`
--

INSERT INTO `sce_tieups` (`id`, `dept_id`, `title`, `image1`, `image2`, `message`) VALUES
(1, 101, 'SIT', NULL, NULL, 'qqqqqqqqqqwwwwwwwweeeeeeerrrrrrrttttttttyyyyyyuuuuuuiiii'),
(2, 101, 'SIT', NULL, NULL, 'tttttttttttffffffffffvvvvvvvvvvccccccbbbbbbbbbb'),
(3, 102, 'AAA', NULL, NULL, 'qqqqqqqqqqqqqwaaaaaaaxxxzzzzzzzzzzvvvv'),
(4, 103, 'UUUUU', NULL, NULL, 'uuuuuuuuuuuuuuuuuuuuaaaaaaaaaaaaaaallllll'),
(5, 104, 'OOOOOOOOOO', NULL, NULL, 'bbbbbbbbbbbbbbbffffffffffgggghhhhhhhhhh'),
(6, 105, 'KKKKKKKKKKKK', NULL, NULL, 'ccccccccvffffffghhhhhhhhhhhhh'),
(7, 111, 'BBBBBAA', NULL, NULL, 'yyyyytttrrrrrrrrffffffffffff');
